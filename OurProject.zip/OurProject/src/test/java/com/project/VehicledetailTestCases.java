package com.project;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.project.layer2.Vehicledetail;
import com.project.layer3.VehicleDetailsRepository;

@SpringBootTest
public class VehicledetailTestCases {


	@Autowired
	VehicleDetailsRepository vehicleRepo;
	
	@Test
	public void testInsertNewVehicleDetails() {//successful
		Vehicledetail vehicle = new Vehicledetail();
		
		
		vehicle.setCompany("TATA");
        vehicle.setModel("nano");
		vehicle.setColor("Red");
		vehicle.setVariant("VDI");
        vehicle.setExshowroomprice(100000);
        vehicle.setOnroadprice(300000);
		
		
		vehicleRepo.addVehicleDetails(vehicle);
	}
	@Test
	public void testModifyVehicleDetail() {//successful but error =again creating new row
		Vehicledetail vri = new Vehicledetail();
		

		vri.setCompany("TATA");
		vri.setModel("nano");
        vri.setColor("Grey");
		vri.setVariant("HTX");
		vri.setExshowroomprice(100000);
        vri.setOnroadprice(300000);	
		
		vehicleRepo.modifyVehicleDetails(vri);
		
	}
	@Test
	public void testRemoveVehicleDetails() {//successful
		

		vehicleRepo.removeVehicleDetails(70);
		
	}
	@Test
	public void testFindVehicleDetails() {
		
		Vehicledetail vehicle=vehicleRepo.findVehicleDetails(1);
		System.out.println(vehicle.getVehicleid());
		System.out.println(vehicle.getModel());
		System.out.println(vehicle.getColor());
		System.out.println(vehicle.getVariant());
		System.out.println(vehicle.getExshowroomprice());
                System.out.println(vehicle.getOnroadprice());
		System.out.println("-----------------");
	
	}
	@Test
	public void testAllFindVehicleDetails() {
		
		Set<Vehicledetail> vehicleset = vehicleRepo.findAllVehicleDetails();
		for (Vehicledetail vehicle: vehicleset) {
		System.out.println(vehicle.getVehicleid());
		System.out.println(vehicle.getModel());
		System.out.println(vehicle.getColor());
		System.out.println(vehicle.getVariant());
		System.out.println(vehicle.getExshowroomprice());
                System.out.println(vehicle.getOnroadprice());
	        System.out.println("-----------------");
	}
		
	}
}
