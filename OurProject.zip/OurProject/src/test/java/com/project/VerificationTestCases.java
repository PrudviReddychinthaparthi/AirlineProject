package com.project;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.project.layer2.Verification;
import com.project.layer3.VerificationRepository;

@SpringBootTest
public class VerificationTestCases {
@Autowired
VerificationRepository vrepo;

@Test
public void VerificationInsert() {
	Verification ver=new Verification();
    ver.setAdhaarcarddoc("uploaded");
    ver.setPancarddoc("uploaded");
    ver.setSalaryslip("uploaded");
	
    vrepo.addVerificationDetails(ver);
}

@Test
public void removeVerification() {
	vrepo.removeVerification(105);
}

        @Test
public void VerificationModify() {
        	Verification ver=new Verification();
        	ver.setAdhaarcarddoc("uploaded");
        	ver.setPancarddoc("uploaded");
        	ver.setSalaryslip("uploaded");

        	vrepo.modifyVerification(ver);

}

@Test
public void VerificationFindAll() {

Set<Verification> vset=vrepo.findVerificationDetails();

	for(Verification ver:vset) {
		System.out.println(ver.getVerificationnumber());
		System.out.println(ver.getAdhaarcarddoc());
		System.out.println(ver.getPancarddoc());
		System.out.println(ver.getSalaryslip());

}
}

@Test
public void VerificationFind() {
      Verification ver=vrepo.findVerificationDetail(201);

                System.out.println(ver.getVerificationnumber());
                System.out.println(ver.getAdhaarcarddoc());
                System.out.println(ver.getPancarddoc());
                System.out.println(ver.getSalaryslip());
                System.out.println("-----------------");
}

}
