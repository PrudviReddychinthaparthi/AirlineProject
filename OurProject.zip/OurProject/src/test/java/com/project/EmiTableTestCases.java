package com.project;

import java.sql.Date;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.project.layer2.Emitable;
import com.project.layer3.EmiTableRepository;

@SpringBootTest 
public class EmiTableTestCases {
	
	@Autowired
	EmiTableRepository emiRepo;
	@Test
	 public void testInsertNewEmi() {
		Emitable emi=new Emitable();
		String str1="2021-04-15";
		 Date date1=Date.valueOf(str1);
		emi.setAppldate(date1);
		String str2="2021-04-19";
		 Date date2=Date.valueOf(str2);
		 emi.setApproveddate(date2);
		 emi.setEmiamount(12000);
		 emi.setLoanamount(1000000);
		 emi.setMonthlyemidate(5);
	emiRepo.addEmiDetails(emi);
	}
	@Test
	public void testModifyEmiDetails() {
		Emitable emi=new Emitable();
		
		String str1="2021-04-15";
		 Date date1=Date.valueOf(str1);
		emi.setAppldate(date1);
		String str2="2021-04-19";
		 Date date2=Date.valueOf(str2);
		 emi.setApproveddate(date2);
		 emi.setEmiamount(15000);
		 emi.setLoanamount(1500000);
		 emi.setMonthlyemidate(5);
		
		
		emiRepo.modifyEmiDetails(emi);
		
	}
	@Test
	public void testRemoveEmiDetails() {
		emiRepo.removeEmiDetails(1005);
		
	}
	@Test
	public void testFindEmiDetails() {
		Emitable emi=emiRepo.findEmiDetails(1001);
		System.out.println(emi.getEmiid());
		System.out.println(emi.getEmiamount());
		System.out.println(emi.getAppldate());
		System.out.println(emi.getEmiamount());
		System.out.println(emi.getMonthlyemidate());
                System.out.println("-----------------");
	
	}
	@Test
	public void testFindAllEmiDetails() {
		Set<Emitable> emiset = emiRepo.findAllEmiDetails();
		for (Emitable emi: emiset) {
		System.out.println(emi.getEmiid());
		System.out.println(emi.getEmiamount());
		System.out.println(emi.getAppldate());
		System.out.println(emi.getEmiamount());
		System.out.println(emi.getMonthlyemidate());
	        System.out.println("-----------------");
	}
		
	}
	
}
