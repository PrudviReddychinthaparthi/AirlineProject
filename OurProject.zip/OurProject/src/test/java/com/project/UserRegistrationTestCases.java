
 package com.project;
 
 import java.sql.Date; import java.util.Set;
 
 import org.junit.jupiter.api.Test; import
 org.springframework.beans.factory.annotation.Autowired; import
 org.springframework.boot.test.context.SpringBootTest;
 
 import com.project.layer2.Userregistration;
import com.project.layer3.UserRegistrationRepository; 
 
 @SpringBootTest
 public class UserRegistrationTestCases {
 
 @Autowired 
 UserRegistrationRepository userreg;
 
 @Test
 public void testInsertNewUser() { //successful
	 Userregistration user = new Userregistration();
	 user.setEmail("k@gmail.com");
	 user.setPassword("Hello123@");
	 user.setAltermobile("9381266408");
	 user.setCity("Madanapalli");
	 String str="1999-01-15";
	 Date date=Date.valueOf(str);
	 user.setDob(date);
	 user.setFname("Koushik");
	 user.setMname("Reddy");
	 user.setLname("Nuthanakaluva");
	 user.setGender("male");
	 user.setMobile("9347413939");
	 user.setPanid("ISQPK3456D");
	 user.setPincode(517299);
	 user.setState("AndhraPradesh");
	 userreg.addUser(user);	 
 }
 
 @Test public void testModifyUser() {
	 Userregistration user = new Userregistration();
	 user.setEmail("k@gmail.com");
	 user.setPassword("Hello123@");
	 user.setAltermobile("9381266408");
	 user.setCity("Madanapalli");
	 String str="1999-01-15";
	 Date date=Date.valueOf(str);
	 user.setDob(date);
	 user.setFname("KOUSHIK");
	 user.setMname("REDDY");
	 user.setLname("Nuthanakaluva");
	 user.setGender("male");
	 user.setMobile("9347413939");
	 user.setPanid("ISQPK3456D");
	 user.setPincode(517299);
	 user.setState("AndhraPradesh");
	 
	 userreg.modifyUser(user);
	 
 }
 
 @Test public void testRemoveUser() {//successful
 
 userreg.removeUser(68); }
 
 @Test public void testUserFind() { 
	 Userregistration user=userreg.findUser(101);
 
 System.out.println(user.getFname());
 System.out.println(user.getMname());
 System.out.println(user.getLname());
 System.out.println(user.getDob());
 System.out.println(user.getGender());
 System.out.println(user.getMobile());
 System.out.println(user.getAltermobile());
 System.out.println(user.getEmail()); 
 System.out.println(user.getPassword()); 
 System.out.println(user.getState());
 System.out.println(user.getCity());
 System.out.println(user.getPincode());
 System.out.println(user.getPanid());
 
 }
 
 @Test public void testFindUsers() {
	 Set<Userregistration> userList=userreg.findUsers(); 
	 for (Userregistration user: userList) {
		 System.out.println(user.getFname());
		 System.out.println(user.getMname());
		 System.out.println(user.getLname());
		 System.out.println(user.getDob());
		 System.out.println(user.getGender());
		 System.out.println(user.getMobile());
		 System.out.println(user.getAltermobile());
		 System.out.println(user.getEmail()); 
		 System.out.println(user.getPassword()); 
		 System.out.println(user.getState());
		 System.out.println(user.getCity());
		 System.out.println(user.getPincode());
		 System.out.println(user.getPanid());
		 
	 }
 }
 }
 
 