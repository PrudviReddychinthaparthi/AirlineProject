package com.project;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.project.layer2.Loandetail;

import com.project.layer3.LoanDetailsRepository;

@SpringBootTest
public class LoanDetailsTestCases {

	@Autowired
	LoanDetailsRepository loanRepo;
	

	@Test
	public void testInsertNewLoan() {
		Loandetail loan = new Loandetail();
		
		        //loan.setLoanId(1006);  
                //loan.setApplicationnumber(206);
                loan.setAmtreq(800000);
                loan.setTenure(84);
                loan.setInterest(7.5);
                loan.setStatus("Approved");

                loanRepo.addLoan(loan);
	}
	@Test
	public void testLoanModify() {
		
		Loandetail loan = new Loandetail();
				//loan.setLoanId(1006);
                //loan.setVehicle(6);
                //loan.setApplicationNumber(206);
                loan.setAmtreq(900000);
                loan.setTenure(84);
                loan.setInterest(8);
                loan.setStatus("Approved");
               

		loanRepo.modifyLoan(loan);
		
	}
		

	@Test
	public void testRemoveLoan() {
		loanRepo.removeLoan(1005);
		
	}

	@Test
	public void testFindLoan() {
		Loandetail loan=loanRepo.findLoan(1005);
		System.out.println(loan.getLoanid());
                System.out.println(loan.getVehicledetail());
                System.out.println(loan.getApplicationdetail());
		System.out.println(loan.getAmtreq());
                System.out.println(loan.getTenure());
                System.out.println(loan.getInterest());
                System.out.println(loan.getStatus());
                
		
		System.out.println("-----------------");
		
	}
	
	
	@Test
	public void testFindAllloan() {
		Set<Loandetail> loanset = loanRepo.findLoans();
		for (Loandetail loan: loanset) {
	        System.out.println(loan.getLoanid());
                System.out.println(loan.getVehicledetail());
                System.out.println(loan.getApplicationdetail());
		System.out.println(loan.getAmtreq());
                System.out.println(loan.getTenure());
                System.out.println(loan.getInterest());
                System.out.println(loan.getStatus());
		System.out.println("-----------------");
		}
	}
	
	
}