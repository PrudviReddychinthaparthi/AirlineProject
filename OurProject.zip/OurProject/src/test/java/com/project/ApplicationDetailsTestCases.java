package com.project;


import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.project.layer2.Applicationdetail;
import com.project.layer3.ApplicationDetailsRepository;
@SpringBootTest
public class ApplicationDetailsTestCases {
	@Autowired
	ApplicationDetailsRepository appRepo;
	
	@Test
	public void testApplicationInsert() {
	Applicationdetail app=new Applicationdetail();
		app.setApplicationnumber(206);
        //app.setUserId(106),
        app.setAddress("Nellore");
        app.setAadhaarid("123456789101");
        app.setAccno("123AP50099");
        app.setBranch("SBI");
        app.setIfsc("2006BDC900");
        app.setAcctype("Savings");
        app.setOccupation("Coading Expert");
        app.setAnnualincome(500000);
        app.setExistingemi(0);

	appRepo.addApplicationDetails(app);
	}
     

        @Test
	public void testApplicationModify() {
        	Applicationdetail app=new Applicationdetail();
    		app.setApplicationnumber(206);
            //app.setUserId(106),
            app.setAddress("Nellore");
            app.setAadhaarid("123456789101");
            app.setAccno("123AP50099");
            app.setBranch("SBI");
            app.setIfsc("2006BDC900");
            app.setAcctype("Savings");
            app.setOccupation("Coading Expert");
            app.setAnnualincome(500000);
            app.setExistingemi(0);

    	appRepo.addApplicationDetails(app);
	}


        @Test
	public void testRemoveApplication() {
	 appRepo.removeApplicationDetails(205);
	}	


        @Test
	public void testFindApplication() {
		Applicationdetail app=appRepo.findApplicationDetails(202);
		System.out.println(app.getApplicationnumber());
//               System.out.println(app.getUserid()); 
                System.out.println(app.getAddress());
                System.out.println(app.getAadhaarid());
		System.out.println(app.getAccno());
                System.out.println(app.getBranch());
                System.out.println(app.getIfsc());
                System.out.println(app.getAcctype());
                System.out.println(app.getOccupation());
                System.out.println(app.getAnnualincome());
                System.out.println(app.getExistingemi());
                
                
		
		System.out.println("-----------------");
		
	}
	
	
	@Test
	public void testFindApplications() {
		Set<Applicationdetail> applicationset = appRepo.findAllApplicationDetails();
		for (Applicationdetail app: applicationset) {
	        System.out.println(app.getApplicationnumber());
               // System.out.println(app.getUserId()); 
                System.out.println(app.getAddress());
                System.out.println(app.getAadhaarid());
		System.out.println(app.getAccno());
                System.out.println(app.getBranch());
                System.out.println(app.getIfsc());
                System.out.println(app.getAcctype());
                System.out.println(app.getOccupation());
                System.out.println(app.getAnnualincome());
                System.out.println(app.getExistingemi());
                
		System.out.println("-----------------");
		}
	}
	
	
}
