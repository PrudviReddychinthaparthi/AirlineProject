package com.project.layer2;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the USERREGISTRATION database table.
 * 
 */
@Entity
@NamedQuery(name="Userregistration.findAll", query="SELECT u FROM Userregistration u")
public class Userregistration implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int userid;

	private String altermobile;

	private String city;

	@Temporal(TemporalType.DATE)
	private Date dob;

	private String email;

	private String fname;

	private String gender;

	private String lname;

	private String mname;

	private String mobile;

	private String panid;

	private String password;

	private long pincode;

	
	private String state;

	//bi-directional many-to-one association to Applicationdetail
	@OneToMany(mappedBy="userregistration", fetch=FetchType.EAGER)
	private Set<Applicationdetail> applicationdetails;

	public Userregistration() {
	}

	public int getUserid() {
		return this.userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getAltermobile() {
		return this.altermobile;
	}

	public void setAltermobile(String altermobile) {
		this.altermobile = altermobile;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Date getDob() {
		return this.dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFname() {
		return this.fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getLname() {
		return this.lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getMname() {
		return this.mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getMobile() {
		return this.mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getPanid() {
		return this.panid;
	}

	public void setPanid(String panid) {
		this.panid = panid;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public long getPincode() {
		return this.pincode;
	}

	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Set<Applicationdetail> getApplicationdetails() {
		return this.applicationdetails;
	}

	public void setApplicationdetails(Set<Applicationdetail> applicationdetails) {
		this.applicationdetails = applicationdetails;
	}

	public Applicationdetail addApplicationdetail(Applicationdetail applicationdetail) {
		getApplicationdetails().add(applicationdetail);
		applicationdetail.setUserregistration(this);

		return applicationdetail;
	}

	public Applicationdetail removeApplicationdetail(Applicationdetail applicationdetail) {
		getApplicationdetails().remove(applicationdetail);
		applicationdetail.setUserregistration(null);

		return applicationdetail;
	}

}