package com.project.layer2;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the VEHICLEDETAILS database table.
 * 
 */
@Entity
@Table(name="VEHICLEDETAILS")
@NamedQuery(name="Vehicledetail.findAll", query="SELECT v FROM Vehicledetail v")
public class Vehicledetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int vehicleid;

	private String color;

	private String company;

	private long exshowroomprice;

	private String model;

	private long onroadprice;

	private String variant;

	//bi-directional many-to-one association to Loandetail
	@OneToMany(mappedBy="vehicledetail", fetch=FetchType.EAGER)
	private Set<Loandetail> loandetails;

	public Vehicledetail() {
	}

	public int getVehicleid() {
		return this.vehicleid;
	}

	public void setVehicleid(int vehicleid) {
		this.vehicleid = vehicleid;
	}

	public String getColor() {
		return this.color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getCompany() {
		return this.company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public long getExshowroomprice() {
		return this.exshowroomprice;
	}

	public void setExshowroomprice(long exshowroomprice) {
		this.exshowroomprice = exshowroomprice;
	}

	public String getModel() {
		return this.model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public long getOnroadprice() {
		return this.onroadprice;
	}

	public void setOnroadprice(long onroadprice) {
		this.onroadprice = onroadprice;
	}

	public String getVariant() {
		return this.variant;
	}

	public void setVariant(String variant) {
		this.variant = variant;
	}

	public Set<Loandetail> getLoandetails() {
		return this.loandetails;
	}

	public void setLoandetails(Set<Loandetail> loandetails) {
		this.loandetails = loandetails;
	}

	public Loandetail addLoandetail(Loandetail loandetail) {
		getLoandetails().add(loandetail);
		loandetail.setVehicledetail(this);

		return loandetail;
	}

	public Loandetail removeLoandetail(Loandetail loandetail) {
		getLoandetails().remove(loandetail);
		loandetail.setVehicledetail(null);

		return loandetail;
	}

}