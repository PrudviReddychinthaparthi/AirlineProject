package com.project.layer2;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the VERIFICATION database table.
 * 
 */
@Entity
@NamedQuery(name="Verification.findAll", query="SELECT v FROM Verification v")
public class Verification implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long verificationnumber;

	private String adhaarcarddoc;

	private String pancarddoc;

	private String salaryslip;

	//bi-directional one-to-one association to Applicationdetail
	@OneToOne
	@JoinColumn(name="VERIFICATIONNUMBER")
	private Applicationdetail applicationdetail;

	public Verification() {
	}

	public long getVerificationnumber() {
		return this.verificationnumber;
	}

	public void setVerificationnumber(long verificationnumber) {
		this.verificationnumber = verificationnumber;
	}

	public String getAdhaarcarddoc() {
		return this.adhaarcarddoc;
	}

	public void setAdhaarcarddoc(String adhaarcarddoc) {
		this.adhaarcarddoc = adhaarcarddoc;
	}

	public String getPancarddoc() {
		return this.pancarddoc;
	}

	public void setPancarddoc(String pancarddoc) {
		this.pancarddoc = pancarddoc;
	}

	public String getSalaryslip() {
		return this.salaryslip;
	}

	public void setSalaryslip(String salaryslip) {
		this.salaryslip = salaryslip;
	}

	public Applicationdetail getApplicationdetail() {
		return this.applicationdetail;
	}

	public void setApplicationdetail(Applicationdetail applicationdetail) {
		this.applicationdetail = applicationdetail;
	}

}