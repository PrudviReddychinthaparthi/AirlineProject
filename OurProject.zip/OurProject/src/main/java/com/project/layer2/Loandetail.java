package com.project.layer2;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the LOANDETAILS database table.
 * 
 */
@Entity
@Table(name="LOANDETAILS")
@NamedQuery(name="Loandetail.findAll", query="SELECT l FROM Loandetail l")
public class Loandetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int loanid;

	private long amtreq;

	private double interest;

	private String status;

	private int tenure;

	//bi-directional one-to-one association to Applicationdetail
	@OneToOne(mappedBy="loandetail")
	private Applicationdetail applicationdetail;

	//bi-directional one-to-one association to Emitable
	@OneToOne(mappedBy="loandetail")
	private Emitable emitable;

	//bi-directional many-to-one association to Vehicledetail
	@ManyToOne
	@JoinColumn(name="VEHICLEID")
	private Vehicledetail vehicledetail;

	public Loandetail() {
	}

	public int getLoanid() {
		return this.loanid;
	}

	public void setLoanid(int loanid) {
		this.loanid = loanid;
	}

	public long getAmtreq() {
		return this.amtreq;
	}

	public void setAmtreq(long amtreq) {
		this.amtreq = amtreq;
	}

	public double getInterest() {
		return this.interest;
	}

	public void setInterest(double interest) {
		this.interest = interest;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getTenure() {
		return this.tenure;
	}

	public void setTenure(int tenure) {
		this.tenure = tenure;
	}

	public Applicationdetail getApplicationdetail() {
		return this.applicationdetail;
	}

	public void setApplicationdetail(Applicationdetail applicationdetail) {
		this.applicationdetail = applicationdetail;
	}

	public Emitable getEmitable() {
		return this.emitable;
	}

	public void setEmitable(Emitable emitable) {
		this.emitable = emitable;
	}

	public Vehicledetail getVehicledetail() {
		return this.vehicledetail;
	}

	public void setVehicledetail(Vehicledetail vehicledetail) {
		this.vehicledetail = vehicledetail;
	}

}