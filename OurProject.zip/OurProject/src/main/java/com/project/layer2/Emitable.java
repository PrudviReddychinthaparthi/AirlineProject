package com.project.layer2;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the EMITABLE database table.
 * 
 */
@Entity
@NamedQuery(name="Emitable.findAll", query="SELECT e FROM Emitable e")
public class Emitable implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long emiid;

	@Temporal(TemporalType.DATE)
	private Date appldate;

	@Temporal(TemporalType.DATE)
	private Date approveddate;

	private long emiamount;

	private long loanamount;

	private int monthlyemidate;

	//bi-directional one-to-one association to Loandetail
	@OneToOne
	@JoinColumn(name="EMIID")
	private Loandetail loandetail;

	public Emitable() {
	}

	public long getEmiid() {
		return this.emiid;
	}

	public void setEmiid(long emiid) {
		this.emiid = emiid;
	}

	public Date getAppldate() {
		return this.appldate;
	}

	public void setAppldate(Date appldate) {
		this.appldate = appldate;
	}

	public Date getApproveddate() {
		return this.approveddate;
	}

	public void setApproveddate(Date approveddate) {
		this.approveddate = approveddate;
	}

	public long getEmiamount() {
		return this.emiamount;
	}

	public void setEmiamount(long emiamount) {
		this.emiamount = emiamount;
	}

	public long getLoanamount() {
		return this.loanamount;
	}

	public void setLoanamount(long loanamount) {
		this.loanamount = loanamount;
	}

	public int getMonthlyemidate() {
		return this.monthlyemidate;
	}

	public void setMonthlyemidate(int monthlyemidate) {
		this.monthlyemidate = monthlyemidate;
	}

	public Loandetail getLoandetail() {
		return this.loandetail;
	}

	public void setLoandetail(Loandetail loandetail) {
		this.loandetail = loandetail;
	}

}