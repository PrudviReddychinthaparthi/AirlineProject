package com.project.layer2;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the APPLICATIONDETAILS database table.
 * 
 */
@Entity
@Table(name="APPLICATIONDETAILS")
@NamedQuery(name="Applicationdetail.findAll", query="SELECT a FROM Applicationdetail a")
public class Applicationdetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int applicationnumber;

	private String aadhaarid;

	private String accno;

	private String acctype;

	private String address;

	private long annualincome;

	private String branch;

	private int existingemi;

	private String ifsc;

	private String licence;

	private String occupation;

	//bi-directional one-to-one association to Loandetail
	@OneToOne
	@JoinColumn(name="APPLICATIONNUMBER", referencedColumnName="APPLICATIONNUMBER")
	private Loandetail loandetail;

	//bi-directional many-to-one association to Userregistration
	@ManyToOne
	@JoinColumn(name="USERID")
	private Userregistration userregistration;

	//bi-directional one-to-one association to Verification
	@OneToOne(mappedBy="applicationdetail")
	private Verification verification;

	public Applicationdetail() {
	}

	public int getApplicationnumber() {
		return this.applicationnumber;
	}

	public void setApplicationnumber(int applicationnumber) {
		this.applicationnumber = applicationnumber;
	}

	public String getAadhaarid() {
		return this.aadhaarid;
	}

	public void setAadhaarid(String aadhaarid) {
		this.aadhaarid = aadhaarid;
	}

	public String getAccno() {
		return this.accno;
	}

	public void setAccno(String accno) {
		this.accno = accno;
	}

	public String getAcctype() {
		return this.acctype;
	}

	public void setAcctype(String acctype) {
		this.acctype = acctype;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getAnnualincome() {
		return this.annualincome;
	}

	public void setAnnualincome(long annualincome) {
		this.annualincome = annualincome;
	}

	public String getBranch() {
		return this.branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public int getExistingemi() {
		return this.existingemi;
	}

	public void setExistingemi(int existingemi) {
		this.existingemi = existingemi;
	}

	public String getIfsc() {
		return this.ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public String getLicence() {
		return this.licence;
	}

	public void setLicence(String licence) {
		this.licence = licence;
	}

	public String getOccupation() {
		return this.occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public Loandetail getLoandetail() {
		return this.loandetail;
	}

	public void setLoandetail(Loandetail loandetail) {
		this.loandetail = loandetail;
	}

	public Userregistration getUserregistration() {
		return this.userregistration;
	}

	public void setUserregistration(Userregistration userregistration) {
		this.userregistration = userregistration;
	}

	public Verification getVerification() {
		return this.verification;
	}

	public void setVerification(Verification verification) {
		this.verification = verification;
	}

}