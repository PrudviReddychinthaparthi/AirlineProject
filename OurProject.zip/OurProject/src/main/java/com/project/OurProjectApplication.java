package com.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OurProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(OurProjectApplication.class, args);
	System.out.println("Our Project Started");
	}

}
