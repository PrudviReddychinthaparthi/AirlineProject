package com.project.layer3;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.project.layer2.Emitable;
@Repository
public class EmiTableRepositoryImpl implements EmiTableRepository {

	@PersistenceContext
    EntityManager entityManager;
	
	
	@Transactional
	public void addEmiDetails(Emitable eRef) {
		
		entityManager.persist(eRef);
		
	}

	@Transactional
	public Emitable findEmiDetails(int emino) {
		System.out.println("Emi repo..No scope of business logic here...");
		return
		entityManager.find(Emitable.class,emino);
	}

	
	@Transactional
	public Set<Emitable> findAllEmiDetails() {
		Set<Emitable> emiSet;
		Query query = entityManager.createQuery("from EmiTable");
		
		emiSet = new HashSet(query.getResultList());
			
		
	return emiSet;
	}

	@Transactional
	public void modifyEmiDetails(Emitable eRef) {
		entityManager.merge(eRef);

	}

	@Transactional
	public void removeEmiDetails(int emino) {
		Emitable emiTemp = entityManager.find(Emitable.class,emino);
		entityManager.remove(emiTemp);

	}

}