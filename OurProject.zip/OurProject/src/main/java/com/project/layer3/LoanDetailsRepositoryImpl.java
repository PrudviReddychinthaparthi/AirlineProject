package com.project.layer3;


import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.project.layer2.Loandetail;

@Repository
public class LoanDetailsRepositoryImpl {

	@PersistenceContext
	EntityManager entityManager;
	@Transactional
	public void addLoan(Loandetail lRef)
	{
	entityManager.persist(lRef);
	}
	@Transactional
	public Loandetail findLoan(int lno)
	{
	System.out.println("Loan repo..No scope of business logic here...");
	return
	entityManager.find(Loandetail.class,lno);
	}
	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Loandetail>findLoans() {
	Set<Loandetail>LoanSet;
	Query query=entityManager.createQuery("from LoanDetail");
	LoanSet = new HashSet<Loandetail>(query.getResultList());
	return LoanSet;
	}
	@Transactional 
	public void modifyLoan(Loandetail lRef) {
	entityManager.merge(lRef);
	}
	@Transactional
	public void removeLoan(int lno)
	{
		Loandetail lTemp = entityManager.find(Loandetail.class,lno);
	entityManager.remove(lTemp);
	}

}
