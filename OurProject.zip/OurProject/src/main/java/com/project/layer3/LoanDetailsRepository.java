package com.project.layer3;


import java.util.Set;

import org.springframework.stereotype.Repository;

import com.project.layer2.Loandetail;
@Repository
public interface LoanDetailsRepository {
void addLoan(Loandetail lRef);
void removeLoan(int lno);
void modifyLoan(Loandetail lRef);
Loandetail findLoan(int lno);
Set<Loandetail>findLoans();
}