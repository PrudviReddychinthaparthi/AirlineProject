package com.project.layer3;

import java.util.Set;

import org.springframework.stereotype.Repository;

import com.project.layer2.Emitable;
@Repository
public interface EmiTableRepository {
	void addEmiDetails(Emitable eRef);
	Emitable findEmiDetails(int emino);
	Set<Emitable>findAllEmiDetails();
	void modifyEmiDetails(Emitable eRef);
	void removeEmiDetails(int emino);
}
