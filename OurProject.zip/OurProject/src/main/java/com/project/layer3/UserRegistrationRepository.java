package com.project.layer3;

import java.util.Set;

import org.springframework.stereotype.Repository;

import com.project.layer2.Userregistration;
@Repository
public interface UserRegistrationRepository {
	void addUser(Userregistration userRef);   //C - add/create
	Userregistration findUser(int userRegid);     //R - find/reading
	Set<Userregistration> findUsers();     //R - find all/reading all
	void modifyUser(Userregistration userRef); //U - modify/update
	void removeUser(int userRegid);

}