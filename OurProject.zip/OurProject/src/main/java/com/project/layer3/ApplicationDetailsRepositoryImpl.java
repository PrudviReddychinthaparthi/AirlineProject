package com.project.layer3;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.project.layer2.Applicationdetail;


@Repository
public class ApplicationDetailsRepositoryImpl implements ApplicationDetailsRepository {

	
	@PersistenceContext
	EntityManager entityManager;
	
	@Transactional
	public void addApplicationDetails(Applicationdetail appRef) {
	entityManager.persist(appRef);

	}

	@Transactional
	public Applicationdetail findApplicationDetails(int appno) {
		System.out.println("Loan repo..No scope of business logic here...");
		return
		entityManager.find(Applicationdetail.class,appno);

	}

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Applicationdetail> findAllApplicationDetails() {
		Set<Applicationdetail>ApplicationSet;
		Query query=entityManager.createQuery("from ApplicationDetail");
		
		ApplicationSet=new HashSet<Applicationdetail>(query.getResultList());
		return ApplicationSet;}

    @Transactional
	public void modifyApplicationDetails(Applicationdetail appRef) {
		entityManager.merge(appRef);
	}

	@Transactional
	public void removeApplicationDetails(int appno) {
		Applicationdetail appTemp = entityManager.find(Applicationdetail.class,appno);
		entityManager.remove(appTemp);
	}

}
