package com.project.layer3;


import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.project.layer2.Verification;



@Repository
public class VerificationRepositoryImpl implements VerificationRepository {//isA


@PersistenceContext
EntityManager entityManager;//auto injected by spring by reading
//persistance.xml file

@Transactional//no need of begin transaction and commit rollback
public void addVerificationDetails(Verification vRef) {//usesA
entityManager.persist(vRef);

}

@Transactional
public Verification findVerificationDetail(int uid) {//producesA Department obj
System.out.println("Verification repo....NO scope of bussiness logic here...");
Verification verObj = entityManager.find(Verification.class, uid);
System.out.println(verObj);
return verObj;

}

@SuppressWarnings("unchecked")
@Transactional
public Set<Verification> findVerificationDetails() {
Set<Verification> verSet;
verSet = new HashSet<Verification>();

String queryString = "from Verification";
Query query = entityManager.createQuery(queryString);
verSet =new HashSet(query.getResultList());

return verSet;

}
@Transactional
public void modifyVerification(Verification vRef) {
entityManager.merge(vRef);

}

@Transactional
public void removeVerification(int uid) {
Verification vTemp = entityManager.find(Verification.class,uid);
entityManager.remove(vTemp);

}

}