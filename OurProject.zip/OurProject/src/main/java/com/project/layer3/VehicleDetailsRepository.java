package com.project.layer3;

import java.util.*;

import org.springframework.stereotype.Repository;

import com.project.layer2.Vehicledetail;

@Repository
public interface VehicleDetailsRepository {
void addVehicleDetails(Vehicledetail vRef);
Vehicledetail findVehicleDetails(int vno);
Set<Vehicledetail>findAllVehicleDetails();
void modifyVehicleDetails(Vehicledetail vRef);
void removeVehicleDetails(int vno);

} 