package com.project.layer3;

import java.util.Set;

import org.springframework.stereotype.Repository;

import com.project.layer2.Applicationdetail;
@Repository
public interface ApplicationDetailsRepository {

	void addApplicationDetails(Applicationdetail appRef);
	Applicationdetail findApplicationDetails(int appno);
	Set<Applicationdetail>findAllApplicationDetails();
	void modifyApplicationDetails(Applicationdetail appRef);
	void removeApplicationDetails(int appno);

}
