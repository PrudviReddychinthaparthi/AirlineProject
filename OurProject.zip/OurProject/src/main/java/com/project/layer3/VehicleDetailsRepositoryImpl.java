package com.project.layer3;

import java.util.*;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.project.layer2.Vehicledetail;



@Repository
public class VehicleDetailsRepositoryImpl implements VehicleDetailsRepository {


@PersistenceContext
	 EntityManager entityManager;
										
	
	@Transactional
	public void addVehicleDetails(Vehicledetail vRef) {
		entityManager.persist(vRef);

	}
	
	@Transactional
	public Vehicledetail findVehicleDetails(int vno) {
		System.out.println("VehicleTable Repository....NO scope of bussiness logic here...");
		return entityManager.find(Vehicledetail.class,vno);
		
	}
        
	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Vehicledetail> findAllVehicleDetails() {
		Set<Vehicledetail> vehicleinfoSet;
	vehicleinfoSet = new HashSet<Vehicledetail>();
		
			String queryString = "from VehicleTable";
			Query query = entityManager.createQuery(queryString);
			vehicleinfoSet =new HashSet(query.getResultList());
			
		
		return vehicleinfoSet;
		
		
	}
	
	@Transactional
	public void modifyVehicleDetails(Vehicledetail vRef) {
		entityManager.merge(vRef);

	}

	@Transactional
	public void removeVehicleDetails(int vno) {
		Vehicledetail dTemp = entityManager.find(Vehicledetail.class,vno);
		entityManager.remove(dTemp);
		
	}

}