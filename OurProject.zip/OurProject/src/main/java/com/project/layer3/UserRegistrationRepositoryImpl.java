package com.project.layer3;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.project.layer2.Userregistration;

@Repository
public class UserRegistrationRepositoryImpl implements UserRegistrationRepository {
	@PersistenceContext
    EntityManager entityManager;
	
	
	@Transactional
	public void addUser(Userregistration userRef) {
		// TODO Auto-generated method stub
		entityManager.persist(userRef);
	}

	@Transactional
	public Userregistration findUser(int userRegid) {
		System.out.println("User repo..No scope of business logic here...");
		return entityManager.find(Userregistration.class,userRegid);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Transactional
	public Set<Userregistration> findUsers() {
		Set<Userregistration> userSet;
		Query query = entityManager.createQuery("from UserRegistration");
		
		userSet = new HashSet(query.getResultList());
			
		
	return userSet;
	}

	@Transactional
	public void modifyUser(Userregistration userRef) {
		// TODO Auto-generated method stub
		entityManager.merge(userRef);
	}

	@SuppressWarnings("unused")
	@Transactional
	public void removeUser(int userRegid) {
		// TODO Auto-generated method stub
		Userregistration userTemp = entityManager.find(Userregistration.class,userRegid);
		entityManager.remove(userTemp);
	}
	

}

