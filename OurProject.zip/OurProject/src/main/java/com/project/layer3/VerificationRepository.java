package com.project.layer3;


import java.util.Set;

import org.springframework.stereotype.Repository;

import com.project.layer2.Verification;


@Repository
public interface VerificationRepository {//same as DeparmentDAO

void addVerificationDetails(Verification vRef);   //C - add/create
Verification findVerificationDetail(int uid);     //R - find/reading
Set<Verification> findVerificationDetails();     //R - find all/reading all
void modifyVerification(Verification vRef); //U - modify/update
void removeVerification(int uid); //D - remove/delete
}
